from flask import Flask, render_template, request, redirect, url_for, flash
import urllib.request, json


app = Flask(__name__)

@app.route("/")
def principal():
    return render_template("contact.htm")

if __name__=="__main__":
    app.run(debug=True)