$(document).ready(function() {
    $('#searchForm').submit(function(event) {
        event.preventDefault();
        var searchTerm = $('#searchInput').val();
        $.ajax({
            type: 'POST',
            url: '/buscar',
            data: {'termo': searchTerm},
            success: function(response) {
                $('#results').html(response);
            }
        });
    });
});

